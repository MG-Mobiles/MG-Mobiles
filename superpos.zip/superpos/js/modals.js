/**
 * modals.js — All modal dialogs
 *
 *  openAddProduct()
 *  openEditProduct(id)
 *  openRestock(id)
 *  openPayment()
 *  closeModal()
 */

/* ── Shared helpers ── */

function showModal(html) {
  const mc = document.getElementById('modal-container');
  mc.innerHTML = html;
  // Close on overlay click
  mc.querySelector('.modal-overlay')?.addEventListener('click', e => {
    if (e.target === e.currentTarget) closeModal();
  });
  // Trap focus on first input
  mc.querySelector('input, select, button')?.focus();
}

function closeModal() {
  document.getElementById('modal-container').innerHTML = '';
}

/* ── Add product ── */

function openAddProduct() {
  const catOptions = getCategories()
    .filter(c => c !== 'All')
    .map(c => `<option value="${c}">${c}</option>`)
    .join('');

  showModal(`
    <div class="modal-overlay">
      <div class="modal" onclick="event.stopPropagation()">
        <h2><i class="ti ti-plus" aria-hidden="true"></i> Add product</h2>

        <div class="form-group">
          <label for="f-name">Product name</label>
          <input id="f-name" type="text" placeholder="e.g. Whole Milk 1L" autocomplete="off" />
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="f-cat">Category</label>
            <select id="f-cat" onchange="toggleNewCat()">
              ${catOptions}
              <option value="__new">+ New category…</option>
            </select>
          </div>
          <div class="form-group" id="newcat-group" style="display:none">
            <label for="f-newcat">New category name</label>
            <input id="f-newcat" type="text" placeholder="e.g. Frozen" />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="f-price">Price ($)</label>
            <input id="f-price" type="number" step="0.01" min="0" placeholder="0.00" />
          </div>
          <div class="form-group">
            <label for="f-stock">Initial stock</label>
            <input id="f-stock" type="number" min="0" placeholder="0" />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="f-minstock">Min. stock alert</label>
            <input id="f-minstock" type="number" min="0" placeholder="5" />
          </div>
          <div class="form-group">
            <label for="f-barcode">Barcode (optional)</label>
            <input id="f-barcode" type="text" placeholder="Auto-assigned if blank" />
          </div>
        </div>

        <div class="modal-actions">
          <button class="btn-sm" onclick="closeModal()">Cancel</button>
          <button class="btn-sm btn-primary" onclick="saveNewProduct()">
            <i class="ti ti-check" aria-hidden="true"></i> Add product
          </button>
        </div>
      </div>
    </div>`);
}

function toggleNewCat() {
  const sel = document.getElementById('f-cat');
  document.getElementById('newcat-group').style.display =
    sel.value === '__new' ? 'block' : 'none';
}

function saveNewProduct() {
  const name = document.getElementById('f-name').value.trim();
  let   cat  = document.getElementById('f-cat').value;
  if (cat === '__new') cat = document.getElementById('f-newcat').value.trim();
  const price    = parseFloat(document.getElementById('f-price').value)    || 0;
  const stock    = parseInt(document.getElementById('f-stock').value, 10)  || 0;
  const minStock = parseInt(document.getElementById('f-minstock').value, 10) || 5;
  const barcode  = document.getElementById('f-barcode').value.trim() || String(getNextId());

  if (!name) { showToast('Product name is required'); return; }
  if (!cat)  { showToast('Category is required');     return; }

  const id = getNextId();
  bumpNextId();
  addProduct({ id, name, category: cat, price, stock, minStock, barcode });

  renderStock();
  renderProducts();
  renderCatFilters();
  closeModal();
  showToast(`"${name}" added`);
}

/* ── Edit product ── */

function openEditProduct(id) {
  const p = getProducts().find(x => x.id === id);
  if (!p) return;

  showModal(`
    <div class="modal-overlay">
      <div class="modal" onclick="event.stopPropagation()">
        <h2><i class="ti ti-edit" aria-hidden="true"></i> Edit product</h2>

        <div class="form-group">
          <label for="e-name">Product name</label>
          <input id="e-name" type="text" value="${p.name}" />
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="e-cat">Category</label>
            <input id="e-cat" type="text" value="${p.category}" />
          </div>
          <div class="form-group">
            <label for="e-price">Price ($)</label>
            <input id="e-price" type="number" step="0.01" value="${p.price}" />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="e-minstock">Min. stock alert</label>
            <input id="e-minstock" type="number" min="0" value="${p.minStock}" />
          </div>
          <div class="form-group">
            <label for="e-barcode">Barcode</label>
            <input id="e-barcode" type="text" value="${p.barcode}" />
          </div>
        </div>

        <div class="modal-actions">
          <button class="btn-sm" onclick="closeModal()">Cancel</button>
          <button class="btn-sm btn-primary" onclick="saveEditProduct(${id})">
            <i class="ti ti-check" aria-hidden="true"></i> Save changes
          </button>
        </div>
      </div>
    </div>`);
}

function saveEditProduct(id) {
  const p = getProducts().find(x => x.id === id);
  if (!p) return;

  const name     = document.getElementById('e-name').value.trim()         || p.name;
  const category = document.getElementById('e-cat').value.trim()          || p.category;
  const price    = parseFloat(document.getElementById('e-price').value)    || p.price;
  const minStock = parseInt(document.getElementById('e-minstock').value, 10) || p.minStock;
  const barcode  = document.getElementById('e-barcode').value.trim()       || p.barcode;

  updateProduct({ ...p, name, category, price, minStock, barcode });

  renderStock();
  renderProducts();
  renderCatFilters();
  closeModal();
  showToast('Product updated');
}

/* ── Restock ── */

function openRestock(id) {
  const p = getProducts().find(x => x.id === id);
  if (!p) return;

  showModal(`
    <div class="modal-overlay">
      <div class="modal" onclick="event.stopPropagation()">
        <h2><i class="ti ti-package" aria-hidden="true"></i> Restock</h2>
        <p style="font-size:13px;color:var(--color-text-secondary);margin-bottom:1rem">
          <strong>${p.name}</strong> — current stock: <strong>${p.stock}</strong> units
        </p>
        <div class="form-group">
          <label for="r-qty">Units to add</label>
          <input id="r-qty" type="number" min="1" placeholder="0" autofocus
            onkeydown="if(event.key==='Enter') confirmRestock(${id})" />
        </div>
        <div class="modal-actions">
          <button class="btn-sm" onclick="closeModal()">Cancel</button>
          <button class="btn-sm btn-primary" onclick="confirmRestock(${id})">
            <i class="ti ti-plus" aria-hidden="true"></i> Add stock
          </button>
        </div>
      </div>
    </div>`);
}

function confirmRestock(id) {
  const qty = parseInt(document.getElementById('r-qty').value, 10);
  if (!qty || qty <= 0) { showToast('Enter a valid quantity'); return; }

  const p = getProducts().find(x => x.id === id);
  if (!p) return;
  updateProduct({ ...p, stock: p.stock + qty });

  renderStock();
  renderProducts();
  closeModal();
  showToast(`Added ${qty} unit${qty !== 1 ? 's' : ''} to "${p.name}"`);
}

/* ── Payment ── */

function openPayment() {
  if (!cart.length) return;

  const sub     = cartSubtotal();
  const tax     = cartTax();
  const total   = cartTotal();
  const itemsHtml = cart.map(i => `
    <div class="receipt-line">
      <span>${i.name} ×${i.qty}</span>
      <span>$${(i.price * i.qty).toFixed(2)}</span>
    </div>`).join('');

  showModal(`
    <div class="modal-overlay">
      <div class="modal" onclick="event.stopPropagation()">
        <h2><i class="ti ti-credit-card" aria-hidden="true"></i> Payment — $${total.toFixed(2)}</h2>

        <div class="form-group">
          <label for="pay-method">Payment method</label>
          <select id="pay-method" onchange="onPayMethodChange()">
            <option>Cash</option>
            <option>Credit card</option>
            <option>Debit card</option>
            <option>Mobile pay</option>
          </select>
        </div>

        <div id="cash-group" class="form-group">
          <label for="cash-received">Cash received ($)</label>
          <input id="cash-received" type="number" min="0" step="0.01"
            placeholder="${total.toFixed(2)}"
            oninput="calcChange(${total.toFixed(4)})"
            onkeydown="if(event.key==='Enter') confirmPayment()" />
        </div>

        <div id="change-display" style="display:none" class="change-info"></div>

        <hr class="receipt-divider" />
        <p class="card-title" style="margin-bottom:6px">Order summary</p>
        ${itemsHtml}
        <hr class="receipt-divider" />
        <div class="receipt-line"><span>Subtotal</span><span>$${sub.toFixed(2)}</span></div>
        <div class="receipt-line"><span>Tax (${(TAX_RATE*100).toFixed(0)}%)</span><span>$${tax.toFixed(2)}</span></div>
        <div class="receipt-line" style="font-weight:600;font-size:15px;margin-top:4px">
          <span>Total</span><span>$${total.toFixed(2)}</span>
        </div>

        <div class="modal-actions">
          <button class="btn-sm" onclick="closeModal()">Cancel</button>
          <button class="btn-sm btn-primary" id="confirm-pay-btn" onclick="confirmPayment()">
            <i class="ti ti-check" aria-hidden="true"></i> Confirm payment
          </button>
        </div>
      </div>
    </div>`);
}

function onPayMethodChange() {
  const method   = document.getElementById('pay-method').value;
  const isCash   = method === 'Cash';
  document.getElementById('cash-group').style.display    = isCash ? 'block' : 'none';
  document.getElementById('change-display').style.display = 'none';
  document.getElementById('confirm-pay-btn').disabled    = false;
}

function calcChange(total) {
  const received = parseFloat(document.getElementById('cash-received').value) || 0;
  const cd       = document.getElementById('change-display');
  const btn      = document.getElementById('confirm-pay-btn');

  cd.style.display = received > 0 ? 'block' : 'none';
  if (received >= total) {
    cd.className     = 'change-info change-ok';
    cd.textContent   = `Change: $${(received - total).toFixed(2)}`;
    btn.disabled     = false;
  } else if (received > 0) {
    cd.className     = 'change-info change-short';
    cd.textContent   = `Short by: $${(total - received).toFixed(2)}`;
    btn.disabled     = true;
  }
}

function confirmPayment() {
  const method = document.getElementById('pay-method')?.value || 'Cash';
  const tx     = finaliseCart(method);
  closeModal();
  showToast(`Payment of $${tx.total.toFixed(2)} confirmed — ${method}`);
  renderHistory();
}
